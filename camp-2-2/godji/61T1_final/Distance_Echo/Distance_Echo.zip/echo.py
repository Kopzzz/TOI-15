v = 343
t = eval(input())
s = v*t/2
print("%.1f"%s)
